branch = u'fix'
nightly = False
official = True
version = u'7.7.3.24061702'
version_name = u'32bit Sensation'
